-- Watermelon and crimson database schema
-- Run in Supabase SQL Editor. Keep Row Level Security enabled.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique not null check (char_length(username) between 3 and 24),
  email text,
  created_at timestamptz not null default now()
);
alter table public.profiles enable row level security;

create table if not exists public.conversations (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  type text not null check (type in ('group','direct')),
  invite_code text unique,
  created_by uuid not null references auth.users(id),
  created_at timestamptz not null default now()
);
alter table public.conversations enable row level security;

create table if not exists public.conversation_members (
  conversation_id uuid references public.conversations(id) on delete cascade,
  user_id uuid references auth.users(id) on delete cascade,
  joined_at timestamptz not null default now(),
  primary key (conversation_id,user_id)
);
alter table public.conversation_members enable row level security;

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  sender_id uuid not null references auth.users(id),
  body text not null check (char_length(body) between 1 and 2000),
  created_at timestamptz not null default now()
);
alter table public.messages enable row level security;

create or replace function public.is_conversation_member(cid uuid)
returns boolean language sql stable security definer set search_path=public
as $$ select exists(select 1 from public.conversation_members where conversation_id=cid and user_id=auth.uid()) $$;

create policy "Profiles visible to signed-in users" on public.profiles for select to authenticated using (true);
create policy "Users insert own profile" on public.profiles for insert to authenticated with check (id=auth.uid());
create policy "Users update own profile" on public.profiles for update to authenticated using (id=auth.uid()) with check (id=auth.uid());

create policy "Members can view conversations" on public.conversations for select to authenticated using (public.is_conversation_member(id));
create policy "Members can view memberships" on public.conversation_members for select to authenticated using (public.is_conversation_member(conversation_id));
create policy "Members can view messages" on public.messages for select to authenticated using (public.is_conversation_member(conversation_id));
create policy "Members can send messages" on public.messages for insert to authenticated with check (sender_id=auth.uid() and public.is_conversation_member(conversation_id));

create or replace function public.create_group(group_title text)
returns uuid language plpgsql security definer set search_path=public
as $$
declare cid uuid; code text;
begin
  if auth.uid() is null then raise exception 'Please log in first'; end if;
  if length(trim(group_title)) < 2 then raise exception 'Group name is too short'; end if;
  code := upper(substr(encode(gen_random_bytes(8),'hex'),1,10));
  insert into public.conversations(title,type,invite_code,created_by)
  values(trim(group_title),'group',code,auth.uid()) returning id into cid;
  insert into public.conversation_members(conversation_id,user_id) values(cid,auth.uid());
  return cid;
end $$;

create or replace function public.join_group_by_invite(invite_code text)
returns uuid language plpgsql security definer set search_path=public
as $$
declare cid uuid;
begin
  if auth.uid() is null then raise exception 'Please log in first'; end if;
  select id into cid from public.conversations where conversations.invite_code=upper(trim(join_group_by_invite.invite_code)) and type='group';
  if cid is null then raise exception 'Invite code not found'; end if;
  insert into public.conversation_members(conversation_id,user_id) values(cid,auth.uid()) on conflict do nothing;
  return cid;
end $$;

grant execute on function public.create_group(text) to authenticated;
grant execute on function public.join_group_by_invite(text) to authenticated;

-- Enable realtime for messages (ignore duplicate publication membership errors).
do $$ begin
  alter publication supabase_realtime add table public.messages;
exception when duplicate_object then null; when others then null;
end $$;

-- Note: for production, add an owner-only function/policy to reveal and rotate invite codes.
-- This starter keeps invite codes inside the conversations table and only exposes
-- conversations to their members. Share invite codes out-of-band with trusted friends.
